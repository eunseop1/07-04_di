package kr.human.hello.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;

import kr.human.hello.vo.HelloWorld;
import kr.human.hello.vo.HelloWorldImpl;

@Configuration //이 클래스를 환경 설정 파일로 사용하겠다
public class HelloWorldConfig {
 
	//객체를 스프링 프레임 워크에 등록해준다
    @Bean(name="helloWorld") //HelloWorld객체를 helloworld라는 이름으로 스프링에 등록
    @Description("This is a sample HelloWorld Bean") //설명 달기(안해도 무방)
    public HelloWorld helloWorld() {
        return new HelloWorldImpl();
    }
 
}

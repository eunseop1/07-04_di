package kr.message.di.vo;

public interface Messaging {
    public void sendMessage();
}
